﻿namespace JWTSample.Helpers
{
    public class AppSettings
    {
        public string SecretKey { get; set; }
    }
}
